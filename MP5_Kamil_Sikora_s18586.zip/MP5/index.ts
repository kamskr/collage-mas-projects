import { main } from "./src/main";

main();
