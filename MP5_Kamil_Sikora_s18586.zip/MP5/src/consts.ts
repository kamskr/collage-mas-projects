export const minimalSalary = 2500;
export const maxSalaryChangePercent = 15;

export enum RoutePath {
  personnel = "/personnel",
}
