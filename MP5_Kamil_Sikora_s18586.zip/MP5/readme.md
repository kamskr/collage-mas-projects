# MP2 MAS 2021 S18586 Kamil Sikora

Żeby odpalic projek trzeba w pierwszej kolejnosci zainstalowac wszystkie potrzebne paczki:

```bash
npm install
```

Następnie program mozna odpalic za pomoca:

```bash
npm run start
```
